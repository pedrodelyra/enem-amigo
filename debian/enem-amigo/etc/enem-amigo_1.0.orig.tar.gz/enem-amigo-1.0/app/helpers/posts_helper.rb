module PostsHelper

	def new_post
		@post = Post.new
	end
end