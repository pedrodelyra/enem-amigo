# Defaults for enem-amigo initscript
# sourced by /etc/init.d/enem-amigo
# installed at /etc/default/enem-amigo by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
