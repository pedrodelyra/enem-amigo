?package(enem-amigo):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="enem-amigo" command="/usr/bin/enem-amigo"
